"version": 1,
  "author": "Satria kurniawan",
  "editor": "wokwi",
  "parts": [
    { "type": "wokwi-esp32-devkit-v1", "id": "esp", "top": 183.01, "left": 20.83, "attrs": {} },
    {
      "type": "wokwi-led",
      "id": "led1",
      "top": 73.24,
      "left": 342.21,
      "attrs": { "color": "limegreen" }
    },
    {
      "type": "wokwi-led",
      "id": "led2",
      "top": 73.3,
      "left": 260.53,
      "attrs": { "color": "yellow" }
    },
    {
      "type": "wokwi-led",
      "id": "led3",
      "top": 77.44,
      "left": 182.84,
      "attrs": { "color": "red" }
    },
    {
      "type": "wokwi-resistor",
      "id": "r1",
      "top": 285.15,
      "left": 155.14,
      "attrs": { "value": "1000" }
    },
    {
      "type": "wokwi-resistor",
      "id": "r2",
      "top": 345.02,
      "left": 370.47,
      "attrs": { "value": "1000" }
    },
    {
      "type": "wokwi-resistor",
      "id": "r3",
      "top": 324.18,
      "left": 260.81,
      "attrs": { "value": "1000" }
    }
  ],
  "connections": [
    [ "esp:TX0", "$serialMonitor:RX", "", [] ],
    [ "esp:RX0", "$serialMonitor:TX", "", [] ],
    [ "led3:C", "esp:GND.1", "green", [ "v217.37", "h-73.92" ] ],
    [ "led2:C", "esp:GND.1", "green", [ "v218.43", "h-154.69" ] ],
    [ "led1:C", "esp:GND.1", "green", [ "v215.42", "h-233.29" ] ],
    [ "led3:A", "r1:2", "green", [ "v-5.81", "h28.44", "v1.54" ] ],
    [ "led2:A", "r3:2", "green", [ "v1.41", "h3.08" ] ],
    [ "led1:A", "r2:2", "green", [ "v13.78", "h44.54" ] ],
    [ "r1:1", "esp:D2", "green", [ "v0" ] ],
    [ "r3:1", "esp:D4", "green", [ "v0" ] ],
    [ "r2:1", "esp:D5", "green", [ "v0" ] ]
  ],
  "dependencies": {}
}